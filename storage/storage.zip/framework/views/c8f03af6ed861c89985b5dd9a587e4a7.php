<h1 <?php echo e($attributes->class(['filament-header-heading text-2xl font-bold tracking-tight'])); ?>>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH /home/u727628553/domains/client-louie.online/vendor/filament/filament/src/../resources/views/components/header/heading.blade.php ENDPATH**/ ?>