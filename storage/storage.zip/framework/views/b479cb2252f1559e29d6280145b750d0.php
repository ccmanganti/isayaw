<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.page','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/lesson.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>

    <div class="full-width">

        
        <div class="onboarding" id="onboarding" style="<?php if(Auth::user()->onboarding === 1): ?> display:none; <?php else: ?> display:block; <?php endif; ?>">
            <div class="tutorial-1" id="tutorial-welcome">
                <video src="../img/onboarding/welcome.mp4" autoplay muted loop class="tutorial-welcome"></video>
            </div>
            <div class="tutorial-2" id="tutorial-2">
                <img src="../img/onboarding/study.gif" class="tutorial-study">
            </div>
            <div class="tutorial-3" id="tutorial-3">
                <img src="../img/onboarding/unlock.gif" class="tutorial-unlock">
            </div>
            <div class="tutorial-progress">
                <p id="progress1" class="current-progress">.</p>
                <p id="progress2">.</p>
                <p id="progress3">.</p>
            </div>
            <div class="tutorial-details">
                <p class="tutorial-title" id="tutorial-title">Welcome to iSAYAW!</p>
                <p class="tutorial-desc" id="tutorial-desc">
                   Your <b class="onboarding-intro">I</b>nteractive <b class="onboarding-intro">S</b>upplemental <b class="onboarding-intro">A</b>ssistant <b class="onboarding-intro">Y</b>ou can <b class="onboarding-intro">A</b>ccess via the <b class="onboarding-intro">W</b>eb
                </p>
            </div>
            <div class="tutorial-continue">
                <div class="arrow-continue" id="next-tutorial">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 8.25L21 12m0 0l-3.75 3.75M21 12H3" />
                    </svg>    
                </div>
            </div>
        </div>


        
        

        <div class="greetings" style="<?php if(Auth::user()->onboarding === 1): ?> display:flex; <?php else: ?> display:none; <?php endif; ?>">
            <div class="greeting-container">
                <div class="greeting-con">
                    <span class="greet">Hi <?php echo e(explode(' ',trim(auth()->user()->name))[0]); ?>,</span>
                    <span class="greeting">Great to see you again!</span>
                </div>
            </div>
                
            <img src="../img/logo1.png" alt="iSayaw" class="showcase">
            <div class="user-prog">
                <span class="prog-label">Modules Progressed:</span>
                <span class="prog"><?php echo e((((auth()->user()->progress)/5)*100)."%"); ?></span>
            </div>
            <div class="continue-btn">
                <a href="<?php echo e(('/module-').auth()->user()->progress.('-lesson-1')); ?>" class="continue">
                    <span class="start-read">
                        <?php if(auth()->user()->progress > 1): ?> Continue <?php else: ?> Start <?php endif; ?> Reading
                    </span>
                    <?php if(auth()->user()->progress > 1): ?>
                        <span class="progress-read">
                            &lpar;Module <?php if(auth()->user()->progress < 6): ?> <?php echo e(auth()->user()->progress); ?> <?php else: ?> <?php echo e(auth()->user()->progress-1); ?> <?php endif; ?> &rpar;
                        </span>
                    <?php endif; ?>
                </a>
            </div>    
        </div>

        

        
        <div class="module-nav" style="<?php if(Auth::user()->onboarding === 1): ?> display:flex; <?php else: ?> display:none; <?php endif; ?>">
            <a href="javascript: void(0)" class="nav-module" id="nav-module">Modules</a>
            <a href="javascript: void(0)" class="nav-module inactive" id="nav-exe">Exercises</a>
        </div>
        <div id="modules" style="<?php if(Auth::user()->onboarding === 1): ?> display:flex; <?php else: ?> display:none; <?php endif; ?>">
            <a href="<?php if(Auth::user()->progress < 1): ?> javascript: void(0) <?php endif; ?> /module-1-lesson-1" class="<?php if(Auth::user()->progress < 1): ?> lessonLinkDisable <?php endif; ?> lesson-link" data-aos="flip-down" data-aos-offset="50">
                <div class="lesson lesson1">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Module I</p>
                        <p class="progress-module-desc">Abbreviations and Signs Used</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 1): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/1.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 2): ?> javascript: void(0) <?php endif; ?> /module-2-lesson-1" class="<?php if(Auth::user()->progress < 2): ?> lessonLinkDisable <?php endif; ?> lesson-link" data-aos="flip-down" data-aos-offset="50">
                <div class="lesson lesson2 <?php if(Auth::user()->progress < 2): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Module II</p>
                        <p class="progress-module-desc">Fundamental Positions of Arms and Feet in Folk Dance</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 2): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/2.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 3): ?> javascript: void(0) <?php endif; ?> /module-1-lesson-1" class="<?php if(Auth::user()->progress < 3): ?> lessonLinkDisable <?php endif; ?> lesson-link" data-aos="flip-down" data-aos-offset="50">
                <div class="lesson lesson3 <?php if(Auth::user()->progress < 3): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Module III</p>
                        <p class="progress-module-desc">Common  Dance Terms</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 3): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/3.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 4): ?> javascript: void(0) <?php endif; ?> /module-1-lesson-1" class="<?php if(Auth::user()->progress < 4): ?> lessonLinkDisable <?php endif; ?> lesson-link" data-aos="flip-down" data-aos-offset="50">
                <div class="lesson lesson4 <?php if(Auth::user()->progress < 4): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Module IV</p>
                        <p class="progress-module-desc">Fundamental Folk Dance Steps</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 4): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/4.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 5): ?> javascript: void(0) <?php endif; ?> /module-1-lesson-1" class="<?php if(Auth::user()->progress < 5): ?> lessonLinkDisable <?php endif; ?> lesson-link" data-aos="flip-down" data-aos-offset="50">
                <div class="lesson lesson5 <?php if(Auth::user()->progress < 5): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Module V</p>
                        <p class="progress-module-desc">Dance Formations</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 5): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/5.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>
        </div>

        
        <div id="exercises" style="<?php if(Auth::user()->onboarding === 1): ?> display:flex; <?php else: ?> display:none; <?php endif; ?>">
            <a href="<?php if(Auth::user()->progress < 1): ?> javascript: void(0) <?php endif; ?> /module-1-assessment" class="<?php if(Auth::user()->progress < 1): ?> lessonLinkDisable <?php endif; ?> assessment-link inactive">
                <div class="lesson exercise1">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Assessment I</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 1): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/exam.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 2): ?> javascript: void(0) <?php endif; ?> /module-2-assessment" class="<?php if(Auth::user()->progress < 2): ?> lessonLinkDisable <?php endif; ?> assessment-link inactive">
                <div class="lesson exercise2 <?php if(Auth::user()->progress < 2): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Assessment II</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 2): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/exam.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 3): ?> javascript: void(0) <?php endif; ?> /module-1-assessment" class="<?php if(Auth::user()->progress < 3): ?> lessonLinkDisable <?php endif; ?> assessment-link inactive">
                <div class="lesson exercise3 <?php if(Auth::user()->progress < 3): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Assessment III</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 3): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/exam.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 4): ?> javascript: void(0) <?php endif; ?> /module-1-assessment" class="<?php if(Auth::user()->progress < 4): ?> lessonLinkDisable <?php endif; ?> assessment-link inactive">
                <div class="lesson exercise4 <?php if(Auth::user()->progress < 4): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Assessment IV</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 4): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/exam.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>

            <a href="<?php if(Auth::user()->progress < 5): ?> javascript: void(0) <?php endif; ?> /module-1-assessment" class="<?php if(Auth::user()->progress < 5): ?> lessonLinkDisable <?php endif; ?> assessment-link inactive">
                <div class="lesson exercise5 <?php if(Auth::user()->progress < 5): ?> lessonDisable <?php endif; ?>">
                    <div class="lesson-titles">
                        <p class="progress-module-title">Assessment V</p>
                    </div>
                    <div class="module-icon-wrap">
                        <img src="<?php if(Auth::user()->progress < 5): ?> ../img/progress/module_icon2.png <?php else: ?> ../img/progress/exam.png <?php endif; ?>" alt="" class="module-icon">
                    </div>
                </div>
            </a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
    <script src="../js/style.js"></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH /home/u727628553/domains/client-louie.online/resources/views/filament/pages/lessons.blade.php ENDPATH**/ ?>