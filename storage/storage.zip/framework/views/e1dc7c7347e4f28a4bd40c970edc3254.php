<?php if(filled($brand = config('filament.brand'))): ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'filament-brand text-xl font-bold tracking-tight',
        'dark:text-white' => config('filament.dark_mode'),
    ]) ?>">
        
        <img src="<?php echo e(asset('/img/logo1.png')); ?>" alt="Logo" class="h-10">
    </div>
<?php endif; ?>
<?php /**PATH /home/u727628553/domains/client-louie.online/vendor/filament/filament/src/../resources/views/components/brand.blade.php ENDPATH**/ ?>